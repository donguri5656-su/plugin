package com.yourserver.fishingsystem.listener;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.util.PDCKeys;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class TreasureListener implements Listener {

    @EventHandler
    public void onOpen(PlayerInteractEvent event) {
        // 右クリック判定
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || item.getType() == Material.AIR || !item.hasItemMeta()) return;

        // PDCで宝箱か判定
        var pdc = item.getItemMeta().getPersistentDataContainer();
        String type = pdc.get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING);

        if (type != null && type.equals("treasure")) {
            event.setCancelled(true); // ブロックを置かないようにする

            String treasureId = pdc.get(new org.bukkit.NamespacedKey(FishingSystem.getPlugin(), "treasure_id"), PersistentDataType.STRING);
            if (treasureId != null) {
                // 1個消費して開封
                item.setAmount(item.getAmount() - 1);
                FishingSystem.getPlugin().getTreasureManager().openTreasure(event.getPlayer(), treasureId);
            }
        }
    }
}