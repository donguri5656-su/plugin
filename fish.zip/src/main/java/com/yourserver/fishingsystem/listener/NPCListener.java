package com.yourserver.fishingsystem.listener;

import com.yourserver.fishingsystem.gui.SellGUI;
import com.yourserver.fishingsystem.gui.MedalGUI;
import com.yourserver.fishingsystem.util.PDCKeys;
import org.bukkit.entity.Entity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.persistence.PersistentDataType;

public class NPCListener implements Listener {

    @EventHandler
    public void onNPCInteract(PlayerInteractEntityEvent event) {
        Entity entity = event.getRightClicked();
        var pdc = entity.getPersistentDataContainer();

        // 釣りNPC判定
        if (pdc.has(PDCKeys.IS_NPC, PersistentDataType.BYTE)) {
            event.setCancelled(true); // バニラの取引を阻止

            String type = pdc.get(PDCKeys.NPC_TYPE, PersistentDataType.STRING);
            if ("MEDAL".equals(type)) {
                MedalGUI.openMedalExchange(event.getPlayer());
            } else {
                SellGUI.openSellGUI(event.getPlayer());
            }
        }
    }
}