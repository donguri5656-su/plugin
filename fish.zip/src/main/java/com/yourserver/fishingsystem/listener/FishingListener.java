package com.yourserver.fishingsystem.listener;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.data.PlayerFishData;
import com.yourserver.fishingsystem.data.ContestType;
import com.yourserver.fishingsystem.fish.FishData;
import com.yourserver.fishingsystem.rank.RankData;
import com.yourserver.fishingsystem.item.ItemManager;
import com.yourserver.fishingsystem.item.BaitManager;
import com.yourserver.fishingsystem.util.PDCKeys;
import com.yourserver.fishingsystem.util.ProgressUtil;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.entity.Firework;
import org.bukkit.entity.FishHook;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.Random;

public class FishingListener implements Listener {
    private final Random random = new Random();
    private final MiniMessage mm = MiniMessage.miniMessage();

    @EventHandler
    public void onPreFish(PlayerFishEvent event) {
        if (event.getState() == PlayerFishEvent.State.FISHING) {
            double multiplier = 1.0;
            BaitManager.BaitData bait = getActiveBait(event.getPlayer());
            if (bait != null) multiplier *= bait.timeMult();
            // フィーバー中ならさらに半減
            if (FishingSystem.getPlugin().getContestManager().isFever()) multiplier *= 0.5;

            if (multiplier < 1.0) {
                FishHook hook = event.getHook();
                hook.setWaitTime((int)(hook.getMinWaitTime() * multiplier), (int)(hook.getMaxWaitTime() * multiplier));
            }
        }
    }

    @EventHandler
    public void onFish(PlayerFishEvent event) {
        if (event.getState() != PlayerFishEvent.State.CAUGHT_FISH) return;
        if (!(event.getCaught() instanceof org.bukkit.entity.Item caughtItem)) return;

        Player player = event.getPlayer();
        ItemStack rod = player.getInventory().getItemInMainHand();
        PlayerFishData pData = FishingSystem.getPlugin().getDataManager().getPlayerData(player.getUniqueId());

        double tBonus = 0, expMult = 1.0, mChance = 0, sMult = 1.0, wMult = 1.0, pMult = 1.0;
        String rBias = "NONE";

        if (rod.hasItemMeta()) {
            var pdc = rod.getItemMeta().getPersistentDataContainer();
            tBonus = pdc.getOrDefault(PDCKeys.ROD_TREASURE_BONUS, PersistentDataType.DOUBLE, 0.0);
            expMult = pdc.getOrDefault(PDCKeys.ROD_EXP_BONUS, PersistentDataType.DOUBLE, 1.0);
            mChance = pdc.getOrDefault(PDCKeys.ROD_MEDAL_CHANCE, PersistentDataType.DOUBLE, 0.0);
        }

        BaitManager.BaitData bait = consumeAndGetBait(player);
        if (bait != null) {
            expMult *= bait.expMult(); sMult *= bait.sizeMult(); wMult *= bait.weightMult();
            pMult *= bait.priceMult(); tBonus += bait.treasureBoost(); rBias = bait.rarityBias();
            player.sendMessage(mm.deserialize("<#A1887F>[餌] <white>" + bait.displayName() + " <gray>効果発動中！"));
        }

        // フィーバーボーナス
        if (FishingSystem.getPlugin().getContestManager().isFever()) {
            expMult *= 1.5;
            if (rBias.equals("NONE")) rBias = "UNCOMMON";
        }

        try {
            if (mChance > 0 && (random.nextDouble() * 100) < mChance) startSlotAnimation(player, "1-3");

            if (Math.random() < (0.05 + (tBonus / 100.0))) {
                ItemStack treasure = FishingSystem.getPlugin().getTreasureManager().getRandomTreasureItem();
                if (treasure != null) {
                    caughtItem.setItemStack(treasure);
                    player.sendMessage(mm.deserialize("<gold>★ お宝の気配がする…！ 宝箱を釣り上げた！"));
                    if (FishingSystem.getPlugin().getContestManager().isActive() && FishingSystem.getPlugin().getContestManager().getCurrentType() == ContestType.TREASURE_HUNT)
                        FishingSystem.getPlugin().getContestManager().recordAction(player, 1.0);
                    return;
                }
            }

            FishData fish = FishingSystem.getPlugin().getFishManager().chooseRandomFish(pData.getLevel(), rBias);
            if (fish == null) return;
            RankData rank = FishingSystem.getPlugin().getRankManager().chooseRandomRank();

            double randPercent = rank.minPercent() + (rank.maxPercent() - rank.minPercent()) * Math.random();
            double size = (fish.minSize() + (fish.maxSize() - fish.minSize()) * (randPercent / 100.0)) * sMult;
            double weight = (fish.minWeight() + (fish.maxWeight() - fish.minWeight()) * (randPercent / 100.0)) * wMult;
            double finalPrice = fish.basePrice() * rank.multiplier() * pMult;

            caughtItem.setItemStack(ItemManager.createFishItem(fish.id(), fish.displayName(), fish.rarity(), fish.lore(), fish.customModelData(), rank.id(), size, weight, finalPrice));

            // 通知
            sendCatchNotification(player, fish, rank, size, weight, finalPrice);

            try {
                FishingSystem.getPlugin().getDataManager().updateDex(player.getUniqueId(), fish.id(), size, weight, rank.id());
                if (FishingSystem.getPlugin().getContestManager().isActive()) {
                    double val = switch(FishingSystem.getPlugin().getContestManager().getCurrentType()) {
                        case BIGGEST_WEIGHT, TOTAL_WEIGHT, SMALLEST_WEIGHT -> weight;
                        case LONGEST_SIZE, SHORTEST_SIZE -> size;
                        case TOTAL_PRICE -> finalPrice;
                        case MOST_CATCHES -> 1.0;
                        default -> 0.0;
                    };
                    FishingSystem.getPlugin().getContestManager().recordAction(player, val);
                }

                double expGain = (20.0 * rank.expMultiplier()) * expMult;
                int reqExp = FishingSystem.getPlugin().getLevelManager().getRequiredExp(pData.getLevel());
                if (pData.addExp(expGain, reqExp)) {
                    player.sendMessage(mm.deserialize("<gold><bold>⬆ LEVEL UP! <white>レベル <aqua>" + pData.getLevel()));
                }
                // ※ EconomyCoreの自動同期メモリ管理へ移行したため、旧SQLite側のデータセーブ呼び出し（savePlayerData）は削除されました
                player.sendActionBar(mm.deserialize("<white>Lv.<aqua>" + pData.getLevel() + " " + ProgressUtil.getProgressBar(pData.getExp(), reqExp, 10) + " <yellow>+" + String.format("%.1f", expGain) + " EXP"));
            } catch (Exception e) { e.printStackTrace(); }

        } catch (Exception e) { e.printStackTrace(); }
    }

    private void sendCatchNotification(Player player, FishData fish, RankData rank, double size, double weight, double price) {
        player.playSound(player.getLocation(), rank.sound(), 1.0f, 1.0f);
        if (rank.id().equals("SSS")) {
            spawnFirework(player.getLocation());
            Bukkit.broadcast(mm.deserialize("<gold><bold>!!! 伝説発見 !!! <white>" + player.getName() + " が " + fish.displayName() + " <white>を釣りました！"));
        }
        if (rank.id().contains("S")) {
            player.sendMessage(mm.deserialize("<yellow><bold>━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
            player.sendMessage(mm.deserialize("<aqua>🎣 <bold>BIG FISH!! <white>ランク: <gold><bold>" + rank.id()));
            player.sendMessage(mm.deserialize("<white>種類: " + fish.rarity().getColorTag() + fish.displayName()));
            player.sendMessage(mm.deserialize("<white>サイズ: <yellow>" + String.format("%.1f", size) + "cm <gray>| <white>重量: <gold>" + String.format("%.1f", weight) + "kg"));
            player.sendMessage(mm.deserialize("<gray>売値: <green>" + String.format("%.1f", price) + "円"));
            player.sendMessage(mm.deserialize("<yellow><bold>━━━━━━━━━━━━━━━━━━━━━━━━━━━━"));
        } else {
            player.sendMessage(mm.deserialize("<#4FC3F7>[Fishing] <white>" + fish.displayName() + " <gray>(Rank " + rank.id() + " / " + String.format("%.1f", size) + "cm / " + String.format("%.1f", weight) + "kg)"));
        }
    }

    private BaitManager.BaitData getActiveBait(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.hasItemMeta() && "bait_bag".equals(item.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING))) {
                String data = item.getItemMeta().getPersistentDataContainer().get(PDCKeys.BAIT_BAG_DATA, PersistentDataType.STRING);
                if (data == null || data.isEmpty()) continue;
                ItemStack[] contents = FishingSystem.getPlugin().getBaitManager().deserializeItems(data);
                for (ItemStack b : contents) {
                    if (b != null && b.getType() != Material.AIR) return FishingSystem.getPlugin().getBaitManager().getBaitData(b.getItemMeta().getPersistentDataContainer().get(PDCKeys.BAIT_ID, PersistentDataType.STRING));
                }
            }
        }
        return null;
    }

    private BaitManager.BaitData consumeAndGetBait(Player player) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.hasItemMeta() && "bait_bag".equals(item.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING))) {
                String data = item.getItemMeta().getPersistentDataContainer().get(PDCKeys.BAIT_BAG_DATA, PersistentDataType.STRING);
                if (data == null || data.isEmpty()) continue;
                ItemStack[] contents = FishingSystem.getPlugin().getBaitManager().deserializeItems(data);
                for (ItemStack bStack : contents) {
                    if (bStack != null && bStack.getType() != Material.AIR) {
                        String id = bStack.getItemMeta().getPersistentDataContainer().get(PDCKeys.BAIT_ID, PersistentDataType.STRING);
                        BaitManager.BaitData bd = FishingSystem.getPlugin().getBaitManager().getBaitData(id);
                        bStack.setAmount(bStack.getAmount() - 1);
                        item.editMeta(m -> m.getPersistentDataContainer().set(PDCKeys.BAIT_BAG_DATA, PersistentDataType.STRING, FishingSystem.getPlugin().getBaitManager().serializeItems(contents)));
                        return bd;
                    }
                }
            }
        }
        return null;
    }

    private void startSlotAnimation(Player player, String range) {
        new BukkitRunnable() {
            int count = 0; final String[] icons = {"🎰", "✨", "📀", "💎", "💰"};
            @Override
            public void run() {
                if (count < 10) {
                    player.showTitle(Title.title(mm.deserialize("<yellow>[ " + icons[random.nextInt(5)] + " | " + icons[random.nextInt(5)] + " | " + icons[random.nextInt(5)] + " ]"), mm.deserialize("<white>メダルチャンス..."), Title.Times.times(Duration.ZERO, Duration.ofMillis(500), Duration.ZERO)));
                    player.playSound(player.getLocation(), Sound.BLOCK_NOTE_BLOCK_BIT, 1.0f, 2.0f);
                } else {
                    String[] p = range.split("-");
                    int amt = Integer.parseInt(p[0]) + random.nextInt(Integer.parseInt(p[1]) - Integer.parseInt(p[0]) + 1);
                    player.getInventory().addItem(ItemManager.createMedalItem(amt));
                    player.showTitle(Title.title(mm.deserialize("<#FFD700><bold>[ ✨ | ✨ | ✨ ]"), mm.deserialize("<white>メダル獲得！"), Title.Times.times(Duration.ofMillis(100), Duration.ofSeconds(2), Duration.ofMillis(500))));
                    player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 2.0f);
                    this.cancel();
                }
                count++;
            }
        }.runTaskTimer(FishingSystem.getPlugin(), 0L, 2L);
    }

    private void spawnFirework(Location loc) {
        Firework fw = loc.getWorld().spawn(loc, Firework.class);
        FireworkMeta meta = fw.getFireworkMeta();
        meta.addEffect(FireworkEffect.builder().withColor(Color.YELLOW, Color.ORANGE).with(FireworkEffect.Type.BALL_LARGE).build());
        fw.setFireworkMeta(meta);
    }
}