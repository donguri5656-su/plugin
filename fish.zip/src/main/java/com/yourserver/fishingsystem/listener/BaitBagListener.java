package com.yourserver.fishingsystem.listener;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.util.PDCKeys;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class BaitBagListener implements Listener {

    @EventHandler
    public void onOpen(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        String type = item.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING);
        if ("bait_bag".equals(type)) {
            event.setCancelled(true);
            FishingSystem.getPlugin().getBaitManager().openBaitBag(event.getPlayer(), item);
        }
    }

    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        if (!event.getView().title().toString().contains("餌バッグの中身")) return;
        Player player = (Player) event.getPlayer();
        ItemStack bag = player.getInventory().getItemInMainHand();

        if (bag == null || !bag.hasItemMeta() || !"bait_bag".equals(bag.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING))) {
            // メインハンドにない場合はオフハンドも確認
            bag = player.getInventory().getItemInOffHand();
            if (bag == null || !bag.hasItemMeta() || !"bait_bag".equals(bag.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING))) return;
        }

        String serialized = FishingSystem.getPlugin().getBaitManager().serializeItems(event.getInventory().getContents());
        bag.editMeta(meta -> meta.getPersistentDataContainer().set(PDCKeys.BAIT_BAG_DATA, PersistentDataType.STRING, serialized));
        player.sendMessage("§a餌バッグの中身を保存しました。");
    }
}