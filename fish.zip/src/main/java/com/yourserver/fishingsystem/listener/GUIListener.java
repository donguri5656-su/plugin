package com.yourserver.fishingsystem.listener;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.fish.FishData;
import com.yourserver.fishingsystem.item.ItemManager;
import com.yourserver.fishingsystem.rank.RankData;
import com.yourserver.fishingsystem.util.PDCKeys;
import com.yourserver.fishingsystem.util.VaultHook;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.plain.PlainComponentSerializer;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.Map;

public class GUIListener implements Listener {

    private final MiniMessage mm = MiniMessage.miniMessage();

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (event.getView().title().toString().isEmpty()) return;
        String title = PlainComponentSerializer.plain().serialize(event.getView().title());
        Player player = (Player) event.getWhoClicked();

        if (title.contains("メダル交換所")) {
            event.setCancelled(true);
            ItemStack clicked = event.getCurrentItem();
            if (clicked == null || !clicked.hasItemMeta()) return;
            String exchangeId = clicked.getItemMeta().getPersistentDataContainer().get(PDCKeys.EXCHANGE_ID, PersistentDataType.STRING);
            if (exchangeId != null) processExchange(player, exchangeId);
            return;
        }

        if (title.contains("魚の売却窓口")) {
            if (event.getCurrentItem() != null && event.getCurrentItem().getType() == Material.ORANGE_STAINED_GLASS_PANE) {
                event.setCancelled(true); return;
            }
            if (event.getRawSlot() == 22) {
                event.setCancelled(true);
                executeSell(player, event.getInventory());
            }
            return;
        }

        if (title.contains("魚図鑑") || title.contains("釣り餌カタログ")) {
            event.setCancelled(true);
        }
    }

    /**
     * GUIを閉じた時のアイテム返却処理
     */
    @EventHandler
    public void onClose(InventoryCloseEvent event) {
        String title = PlainComponentSerializer.plain().serialize(event.getView().title());
        if (title.contains("魚の売却窓口")) {
            Player player = (Player) event.getPlayer();
            Inventory inv = event.getInventory();

            // 魚が入るスロット(0〜17)を確認
            for (int i = 0; i < 18; i++) {
                ItemStack item = inv.getItem(i);
                if (item != null && item.getType() != Material.AIR) {
                    // プレイヤーのインベントリに返却
                    Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item);
                    // 入り切らなかった分は地面に落とす
                    for (ItemStack leftover : leftovers.values()) {
                        player.getWorld().dropItemNaturally(player.getLocation(), leftover);
                    }
                    // 二重返却防止のためスロットを空にする
                    inv.setItem(i, null);
                }
            }
        }
    }

    private void processExchange(Player player, String exchangeId) {
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "medal_exchange.yml");
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("exchange." + exchangeId);
        if (section == null) return;

        int cost = section.getInt("medal-cost");
        if (hasEnoughMedals(player, cost)) {
            takeMedals(player, cost);
            giveReward(player, section);
            player.sendMessage(mm.deserialize("<green>アイテムを交換しました！"));
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
            player.closeInventory();
        } else {
            player.sendMessage(mm.deserialize("<red>メダルが足りません！"));
        }
    }

    private boolean hasEnoughMedals(Player player, int cost) {
        int count = 0;
        for (ItemStack item : player.getInventory().getContents()) {
            if (item != null && item.hasItemMeta()) {
                String type = item.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING);
                if ("medal".equals(type)) count += item.getAmount();
            }
        }
        return count >= cost;
    }

    private void takeMedals(Player player, int cost) {
        int remaining = cost;
        ItemStack[] contents = player.getInventory().getContents();
        for (ItemStack item : contents) {
            if (item == null || !item.hasItemMeta()) continue;
            String type = item.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING);
            if ("medal".equals(type)) {
                if (item.getAmount() > remaining) {
                    item.setAmount(item.getAmount() - remaining);
                    remaining = 0;
                } else {
                    remaining -= item.getAmount();
                    item.setAmount(0);
                }
            }
            if (remaining <= 0) break;
        }
        player.getInventory().setContents(contents);
    }

    private void giveReward(Player player, ConfigurationSection section) {
        String type = section.getString("type", "MATERIAL");
        switch (type.toUpperCase()) {
            case "ROD" -> {
                ItemStack rod = FishingSystem.getPlugin().getRodManager().createRod(section.getString("id"));
                if (rod != null) player.getInventory().addItem(rod);
            }
            case "BAG" -> player.getInventory().addItem(FishingSystem.getPlugin().getBaitManager().createBaitBag());
            case "BAIT" -> {
                ItemStack bait = FishingSystem.getPlugin().getBaitManager().createBait(section.getString("id"));
                if (bait != null) {
                    bait.setAmount(section.getInt("amount", 1));
                    player.getInventory().addItem(bait);
                }
            }
            default -> {
                try {
                    Material m = Material.valueOf(section.getString("material", "GOLD_INGOT"));
                    player.getInventory().addItem(new ItemStack(m, section.getInt("amount", 1)));
                } catch (Exception ignored) {}
            }
        }
    }

    private void executeSell(Player player, Inventory inv) {
        double total = 0;
        int count = 0;
        for (int i = 0; i < 18; i++) {
            ItemStack item = inv.getItem(i);
            if (item == null || item.getType() == Material.AIR) continue;
            String fishId = ItemManager.getFishId(item);
            if (fishId == null) continue;
            FishData fish = FishingSystem.getPlugin().getFishManager().getFishById(fishId);
            RankData rank = FishingSystem.getPlugin().getRankManager().getRankById(ItemManager.getRank(item));
            if (fish != null && rank != null) {
                total += (fish.basePrice() * rank.multiplier() * item.getAmount());
                count += item.getAmount();
                inv.setItem(i, null);
            }
        }
        if (total > 0 && VaultHook.getEconomy() != null) {
            VaultHook.getEconomy().depositPlayer(player, total);
            player.sendMessage(mm.deserialize("<#FFB74D>計 " + count + " 匹を売却し、<gold>" + String.format("%.1f", total) + "円 <#FFB74D>を獲得！"));
            player.playSound(player.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0f, 1.0f);
        }
    }
}