package com.yourserver.fishingsystem.listener;

import com.yourserver.fishingsystem.gui.BaitDexGUI;
import com.yourserver.fishingsystem.gui.DexGUI;
import com.yourserver.fishingsystem.util.PDCKeys;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

public class DexItemListener implements Listener {

    @EventHandler
    public void onInteract(PlayerInteractEvent event) {
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        if (item == null || !item.hasItemMeta()) return;

        String type = item.getItemMeta().getPersistentDataContainer().get(PDCKeys.ITEM_TYPE, PersistentDataType.STRING);
        if (type == null) return;

        if (type.equals("fish_dex_item")) {
            event.setCancelled(true);
            DexGUI.openDex(event.getPlayer());
        } else if (type.equals("bait_dex_item")) {
            event.setCancelled(true);
            BaitDexGUI.openBaitDex(event.getPlayer());
        }
    }
}