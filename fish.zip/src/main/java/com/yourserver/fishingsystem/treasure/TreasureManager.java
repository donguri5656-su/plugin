package com.yourserver.fishingsystem.treasure;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.data.PlayerFishData;
import com.yourserver.fishingsystem.util.PDCKeys;
import com.yourserver.fishingsystem.util.VaultHook;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

public class TreasureManager {
    private final List<TreasureData> treasures = new ArrayList<>();
    private final Random random = new Random();

    public void loadTreasures() {
        treasures.clear();
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "treasures.yml");
        if (!file.exists()) FishingSystem.getPlugin().saveResource("treasures.yml", false);
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        if (config.getConfigurationSection("treasures") == null) return;

        for (String key : config.getConfigurationSection("treasures").getKeys(false)) {
            try {
                String path = "treasures." + key;
                String name = config.getString(path + ".display-name", "宝箱");
                double chance = config.getDouble(path + ".chance", 10.0);
                int min = config.getInt(path + ".reward-rolls.min", 1);
                int max = config.getInt(path + ".reward-rolls.max", 1);
                int cmd = config.getInt(path + ".custom-model-data", 2001);

                List<RewardData> rewards = new ArrayList<>();
                List<?> rawList = config.getList(path + ".rewards");
                if (rawList != null) {
                    for (Object obj : rawList) {
                        if (obj instanceof Map) {
                            Map<?, ?> map = (Map<?, ?>) obj;
                            Object typeObj = map.get("type");
                            Object matObj = map.get("material");
                            Object chanceObj = map.get("chance");
                            Object amountObj = map.get("amount");
                            Object cmdObj = map.get("command");

                            String type = (typeObj != null) ? typeObj.toString() : "MONEY";
                            String material = (matObj != null) ? matObj.toString() : "GOLD_INGOT";
                            double rChance = (chanceObj != null) ? Double.parseDouble(chanceObj.toString()) : 50.0;
                            String amount = (amountObj != null) ? amountObj.toString() : "1";
                            String command = (cmdObj != null) ? cmdObj.toString() : "";

                            rewards.add(new RewardData(type, material, rChance, amount, command));
                        }
                    }
                }
                treasures.add(new TreasureData(key, name, chance, min, max, cmd, rewards));
            } catch (Exception e) {
                Bukkit.getLogger().severe("[FishingSystem] 宝箱 '" + key + "' 読み込み失敗");
            }
        }
    }

    public ItemStack getRandomTreasureItem() {
        if (treasures.isEmpty()) return null;
        double total = treasures.stream().mapToDouble(TreasureData::chance).sum();
        double r = random.nextDouble() * total;
        double count = 0;
        TreasureData selected = treasures.get(0);
        for (TreasureData t : treasures) {
            count += t.chance();
            if (r <= count) { selected = t; break; }
        }
        ItemStack chest = new ItemStack(Material.CHEST);
        TreasureData finalT = selected;
        chest.editMeta(meta -> {
            meta.displayName(MiniMessage.miniMessage().deserialize("<reset><gray>" + finalT.displayName()));
            meta.getPersistentDataContainer().set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "treasure");
            meta.getPersistentDataContainer().set(new NamespacedKey(FishingSystem.getPlugin(), "treasure_id"), PersistentDataType.STRING, finalT.id());
            meta.setCustomModelData(finalT.customModelData());
        });
        return chest;
    }

    public void openTreasure(Player player, String id) {
        TreasureData data = treasures.stream().filter(t -> t.id().equals(id)).findFirst().orElse(null);
        if (data == null) return;
        player.sendMessage(MiniMessage.miniMessage().deserialize("<gold>★ " + data.displayName() + " を開封しました！"));
        player.playSound(player.getLocation(), Sound.BLOCK_CHEST_OPEN, 1.0f, 1.0f);
        int min = data.minRolls();
        int max = data.maxRolls();
        int rolls = (max > min) ? min + random.nextInt(max - min + 1) : min;
        for (int i = 0; i < rolls; i++) {
            for (RewardData reward : data.rewards()) {
                if (random.nextDouble() * 100 <= reward.chance()) {
                    applyReward(player, reward);
                }
            }
        }
    }

    private void applyReward(Player player, RewardData reward) {
        try {
            String amountStr = reward.amount();
            int amount;
            if (amountStr.contains("-")) {
                String[] parts = amountStr.split("-");
                amount = Integer.parseInt(parts[0]) + random.nextInt(Integer.parseInt(parts[1]) - Integer.parseInt(parts[0]) + 1);
            } else {
                amount = Integer.parseInt(amountStr);
            }

            var mm = MiniMessage.miniMessage();
            switch (reward.type().toUpperCase()) {
                case "MONEY" -> {
                    if (VaultHook.getEconomy() != null) {
                        VaultHook.getEconomy().depositPlayer(player, amount);
                        player.sendMessage(mm.deserialize("<green>+ " + amount + "円 を獲得！"));
                    }
                }
                case "MATERIAL" -> {
                    Material m = Material.valueOf(reward.material().toUpperCase());
                    ItemStack item = new ItemStack(m, amount);
                    // インベントリに追加し、入らなかった分(leftovers)を地面に落とす
                    Map<Integer, ItemStack> leftovers = player.getInventory().addItem(item);
                    for (ItemStack leftover : leftovers.values()) {
                        player.getWorld().dropItemNaturally(player.getLocation(), leftover);
                    }
                    player.sendMessage(mm.deserialize("<white>+ " + m.name() + " x" + amount + " を獲得！"));
                }
                case "EXP" -> {
                    PlayerFishData pData = FishingSystem.getPlugin().getDataManager().getPlayerData(player.getUniqueId());
                    // プレイヤーの実際の釣りレベルを元に、必要経験値を動的に取得
                    int reqExp = FishingSystem.getPlugin().getLevelManager().getRequiredExp(pData.getLevel());
                    pData.addExp(amount, reqExp);
                    player.sendMessage(mm.deserialize("<aqua>+ " + amount + " 経験値を獲得！"));
                }
                case "COMMAND" -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), reward.command().replace("%player%", player.getName()));
            }
        } catch (Exception ignored) {}
    }

    public record TreasureData(String id, String displayName, double chance, int minRolls, int maxRolls, int customModelData, List<RewardData> rewards) {}
    public record RewardData(String type, String material, double chance, String amount, String command) {}
}