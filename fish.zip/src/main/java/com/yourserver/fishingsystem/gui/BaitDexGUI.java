package com.yourserver.fishingsystem.gui;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.item.BaitManager;
import com.yourserver.fishingsystem.item.ItemManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class BaitDexGUI {

    public static void openBaitDex(Player player) {
        var mm = MiniMessage.miniMessage();
        // 54スロットの大容量GUIを作成
        Inventory inv = Bukkit.createInventory(null, 54, mm.deserialize("<#A1887F>釣り餌カタログ"));

        // 背景と区切り用のラベルを設置
        setupHeaders(inv);

        // ロードされている全ての餌を配置
        for (String id : FishingSystem.getPlugin().getBaitManager().getAllBaitIds()) {
            BaitManager.BaitData data = FishingSystem.getPlugin().getBaitManager().getBaitData(id);
            if (data == null) continue;

            // レア度に基づいて開始スロット（段）を決定
            int startSlot = switch (data.rarity()) {
                case COMMON -> 1;    // 1段目 (1-8)
                case UNCOMMON -> 10; // 2段目 (10-17)
                case RARE -> 19;     // 3段目 (19-26)
                case EPIC -> 28;     // 4段目 (28-35)
                case LEGENDARY, MYTHIC -> 37; // 5段目 (37-44)
                case SPECIAL -> 46;  // 6段目 (46-53)
            };

            // 各段の空いているスロット（1〜8番目）に配置
            for (int i = startSlot; i < startSlot + 8; i++) {
                if (inv.getItem(i) == null) {
                    inv.setItem(i, createBaitIcon(data));
                    break;
                }
            }
        }

        player.openInventory(inv);
    }

    private static void setupHeaders(Inventory inv) {
        // 各段の左端(0, 9, 18, 27, 36, 45)に色付きガラスを置く
        inv.setItem(0, createHeader(Material.WHITE_STAINED_GLASS_PANE, "<white>Common"));
        inv.setItem(9, createHeader(Material.LIME_STAINED_GLASS_PANE, "<green>Uncommon"));
        inv.setItem(18, createHeader(Material.LIGHT_BLUE_STAINED_GLASS_PANE, "<aqua>Rare"));
        inv.setItem(27, createHeader(Material.PURPLE_STAINED_GLASS_PANE, "<light_purple>Epic"));
        // GOLD_STAINED_GLASS_PANE は存在しないため YELLOW に修正
        inv.setItem(36, createHeader(Material.YELLOW_STAINED_GLASS_PANE, "<gold>Legendary/Mythic"));
        inv.setItem(45, createHeader(Material.MAGENTA_STAINED_GLASS_PANE, "<#D485FF>Special"));
    }

    private static ItemStack createHeader(Material mat, String name) {
        ItemStack item = new ItemStack(mat);
        item.editMeta(meta -> meta.displayName(MiniMessage.miniMessage().deserialize("<reset>" + name)));
        return item;
    }

    private static ItemStack createBaitIcon(BaitManager.BaitData data) {
        ItemStack icon = new ItemStack(Material.CLAY_BALL);
        icon.editMeta(meta -> {
            // 名前：レア度の色 + 餌の名前
            meta.displayName(ItemManager.parseColor(data.rarity().getColorTag() + data.displayName()));

            // 説明文の構築
            List<net.kyori.adventure.text.Component> lore = new ArrayList<>();
            lore.add(ItemManager.parseColor("<gray>レア度: " + data.rarity().getColorTag() + data.rarity().getDisplayName()));
            lore.add(net.kyori.adventure.text.Component.empty());

            // baits.yml に書かれた lore (効果説明) を追加
            if (data.lore() != null) {
                for (String line : data.lore()) {
                    lore.add(ItemManager.parseColor(line));
                }
            }

            meta.lore(lore);
            meta.setCustomModelData(data.customModelData());
        });
        return icon;
    }
}