package com.yourserver.fishingsystem.gui;

import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class SellGUI {

    public static void openSellGUI(Player player) {
        var mm = MiniMessage.miniMessage();
        // 27スロット（3段）のインベントリを作成
        Inventory inv = Bukkit.createInventory(null, 27, mm.deserialize("<#FFB74D>魚の売却窓口"));

        // 装飾用のガラス板（下の段を埋める）
        ItemStack pane = new ItemStack(Material.ORANGE_STAINED_GLASS_PANE);
        pane.editMeta(meta -> meta.displayName(mm.deserialize(" ")));

        for (int i = 18; i < 27; i++) {
            inv.setItem(i, pane);
        }

        // 22番スロットに「売却実行」ボタンを配置
        ItemStack sellButton = new ItemStack(Material.GOLD_BLOCK);
        sellButton.editMeta(meta -> {
            meta.displayName(mm.deserialize("<#FFF176><bold>[ 売却を実行する ]"));
            meta.lore(java.util.List.of(
                    mm.deserialize("<gray>上のスロットに魚を入れてください"),
                    mm.deserialize("<gray>クリックすると一括で現金化します")
            ));
        });
        inv.setItem(22, sellButton);

        player.openInventory(inv);
    }
}