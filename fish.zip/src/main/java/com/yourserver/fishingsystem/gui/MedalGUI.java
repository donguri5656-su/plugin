package com.yourserver.fishingsystem.gui;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.item.ItemManager;
import com.yourserver.fishingsystem.util.PDCKeys;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.List;

public class MedalGUI {

    public static void openMedalExchange(Player player) {
        var mm = MiniMessage.miniMessage();
        // インベントリの作成
        Inventory inv = Bukkit.createInventory(null, 27, mm.deserialize("<#FFD700>メダル交換所"));

        File file = new File(FishingSystem.getPlugin().getDataFolder(), "medal_exchange.yml");
        if (!file.exists()) FishingSystem.getPlugin().saveResource("medal_exchange.yml", false);

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("exchange");

        if (section != null) {
            int slot = 10;
            for (String key : section.getKeys(false)) {
                if (slot > 16) break;

                String name = section.getString(key + ".display-name", "景品");
                int cost = section.getInt(key + ".medal-cost", 999);
                String type = section.getString(key + ".type", "MATERIAL");

                // アイコンの決定
                Material mat = Material.PAPER;
                if (type.equals("ROD")) mat = Material.FISHING_ROD;
                else {
                    try { mat = Material.valueOf(section.getString(key + ".material", "GOLD_INGOT")); }
                    catch (Exception e) { mat = Material.GOLD_INGOT; }
                }

                ItemStack icon = new ItemStack(mat);
                icon.editMeta(meta -> {
                    meta.displayName(ItemManager.parseColor(name));
                    meta.lore(List.of(
                            mm.deserialize("<gray>必要メダル: <yellow>" + cost + "枚"),
                            mm.deserialize(""),
                            mm.deserialize("<aqua>クリックして交換する")
                    ));
                    // PDCに景品キーを保存
                    meta.getPersistentDataContainer().set(PDCKeys.EXCHANGE_ID, PersistentDataType.STRING, key);
                });

                inv.setItem(slot++, icon);
            }
        }

        player.openInventory(inv);
    }
}