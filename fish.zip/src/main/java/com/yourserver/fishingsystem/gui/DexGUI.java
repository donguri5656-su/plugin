package com.yourserver.fishingsystem.gui;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.data.FishDexEntry;
import com.yourserver.fishingsystem.fish.FishData;
import com.yourserver.fishingsystem.item.ItemManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class DexGUI {

    public static void openDex(Player player) {
        var mm = MiniMessage.miniMessage();
        Inventory inv = Bukkit.createInventory(null, 54, mm.deserialize("<#4FC3F7>魚図鑑 (百科事典)"));

        Map<String, FishDexEntry> dexData = FishingSystem.getPlugin().getDataManager().getPlayerDex(player.getUniqueId());

        int slot = 0;
        for (FishData fish : FishingSystem.getPlugin().getFishManager().getAllFish()) {
            if (slot >= 54) break;

            ItemStack icon;
            if (dexData.containsKey(fish.id())) {
                FishDexEntry entry = dexData.get(fish.id());
                icon = new ItemStack(Material.COD);
                icon.editMeta(meta -> {
                    meta.displayName(ItemManager.parseColor(fish.rarity().getColorTag() + fish.displayName()));

                    List<Component> lore = new ArrayList<>();
                    lore.add(ItemManager.parseColor("<gray>レア度: " + fish.rarity().getColorTag() + fish.rarity().getDisplayName()));
                    lore.add(ItemManager.parseColor("<gray>解放レベル: <aqua>Lv." + fish.unlockLevel()));
                    lore.add(Component.empty());

                    lore.add(ItemManager.parseColor("<yellow><bold>【獲得済み品質】"));
                    lore.add(mm.deserialize(formatRanks(entry.caughtRanks())));
                    lore.add(Component.empty());

                    lore.add(ItemManager.parseColor("<yellow><bold>【捕獲記録】"));
                    lore.add(ItemManager.parseColor("<white>合計捕獲数: <aqua>" + entry.count() + " 匹"));
                    lore.add(ItemManager.parseColor("<white>最大サイズ: <yellow>" + String.format("%.1f", entry.maxSize()) + " cm"));
                    lore.add(ItemManager.parseColor("<white>最大重量: <gold>" + String.format("%.1f", entry.maxWeight()) + " kg"));

                    meta.lore(lore);
                    meta.setCustomModelData(fish.customModelData());
                });
            } else {
                icon = new ItemStack(Material.BARRIER);
                icon.editMeta(meta -> {
                    meta.displayName(mm.deserialize("<red>未発見の魚 (???)"));
                    List<Component> lore = new ArrayList<>();
                    lore.add(ItemManager.parseColor("<gray>レア度: " + fish.rarity().getColorTag() + fish.rarity().getDisplayName()));
                    lore.add(ItemManager.parseColor("<gray>解放レベル: <aqua>Lv." + fish.unlockLevel()));
                    lore.add(Component.empty());
                    lore.add(ItemManager.parseColor("<gray>まだ釣ったことがありません。"));
                    meta.lore(lore);
                });
            }
            inv.setItem(slot++, icon);
        }
        player.openInventory(inv);
    }

    private static String formatRanks(String raw) {
        if (raw == null || raw.isEmpty()) return "<dark_gray>· · · · · · ·";

        List<String> caughtList = Arrays.asList(raw.split(","));
        String[] allRanks = {"D", "C", "B", "A", "S", "SS", "SSS"};
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < allRanks.length; i++) {
            String r = allRanks[i];
            if (caughtList.contains(r)) {
                String color = switch (r) {
                    case "D" -> "<gray>";
                    case "C" -> "<green>";
                    case "B" -> "<aqua>";
                    case "A" -> "<yellow>";
                    case "S" -> "<gold>";
                    case "SS" -> "<light_purple>";
                    case "SSS" -> "<red>";
                    default -> "<white>";
                };
                sb.append(color).append(r);
            } else {
                sb.append("<dark_gray>·");
            }
            if (i < allRanks.length - 1) sb.append(" ");
        }
        return sb.toString();
    }
}