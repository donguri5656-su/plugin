package com.yourserver.fishingsystem.fish;

import org.bukkit.block.Biome;
import java.util.List;
import java.util.Set;

public record FishData(
        String id,
        String displayName,
        FishRarity rarity,
        int customModelData,
        double chance,
        int unlockLevel,
        List<String> lore,
        double minSize,
        double maxSize,
        double minWeight,
        double maxWeight,
        double basePrice,
        Set<Biome> biomes,
        long minTime,
        long maxTime,
        boolean allowClear,
        boolean allowRain,
        boolean allowThunder
) {}