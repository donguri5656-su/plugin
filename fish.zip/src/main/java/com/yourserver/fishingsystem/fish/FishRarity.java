package com.yourserver.fishingsystem.fish;

public enum FishRarity {
    COMMON("Common", "<white>"),
    UNCOMMON("Uncommon", "<green>"),
    RARE("Rare", "<aqua>"),
    EPIC("Epic", "<light_purple>"),
    LEGENDARY("Legendary", "<gold>"),
    MYTHIC("Mythic", "<red><bold>"),
    SPECIAL("Special", "<#D485FF><bold>"); // 特殊餌用の色

    private final String displayName;
    private final String colorTag;

    FishRarity(String displayName, String colorTag) {
        this.displayName = displayName;
        this.colorTag = colorTag;
    }

    public String getDisplayName() { return displayName; }
    public String getColorTag() { return colorTag; }
}