package com.yourserver.fishingsystem.fish;

import com.yourserver.fishingsystem.FishingSystem;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.*;

public class FishManager {
    private final List<FishData> fishList = new ArrayList<>();
    private final Random random = new Random();

    public void loadFish() {
        fishList.clear();
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "fish.yml");
        if (!file.exists()) FishingSystem.getPlugin().saveResource("fish.yml", false);

        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("fish");
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            try {
                FishRarity rarity = FishRarity.valueOf(section.getString(id + ".rarity", "COMMON").toUpperCase());
                List<String> lore = section.getStringList(id + ".lore");

                // 自動補完 (売値も含める)
                if (lore == null || lore.isEmpty()) {
                    lore = new ArrayList<>();
                    lore.add("サイズ: %size%cm");
                    lore.add("重量: %weight%kg");
                    lore.add("売値: %price%");
                    lore.add("ランク: %rank%");
                }

                fishList.add(new FishData(
                        id, section.getString(id + ".display-name", id), rarity, section.getInt(id + ".custom-model-data", 0),
                        section.getDouble(id + ".chance", 10.0), section.getInt(id + ".unlock-level", 1), lore,
                        section.getDouble(id + ".size.min", 10.0), section.getDouble(id + ".size.max", 100.0),
                        section.getDouble(id + ".weight.min", 1.0), section.getDouble(id + ".weight.max", 10.0),
                        section.getDouble(id + ".base-price", 100.0), new HashSet<>(), 0, 24000, true, true, true
                ));
            } catch (Exception e) {
                Bukkit.getLogger().severe("[FishingSystem] 魚 '" + id + "' の読み込み失敗");
            }
        }
    }

    public FishData chooseRandomFish(int level, String rarityBias) {
        if (fishList.isEmpty()) return null;
        List<FishData> available = new ArrayList<>(fishList.stream().filter(f -> level >= f.unlockLevel()).toList());
        if (available.isEmpty()) available = fishList;

        double totalChance = 0;
        for (FishData f : available) {
            double chance = f.chance();
            if (rarityBias != null && !rarityBias.equals("NONE")) {
                if (f.rarity().name().equals(rarityBias)) chance *= 5.0;
                else if (rarityBias.equals("RARE") && f.rarity() == FishRarity.COMMON) chance *= 0.5;
            }
            totalChance += chance;
        }

        double r = random.nextDouble() * totalChance;
        double count = 0;
        for (FishData f : available) {
            double chance = f.chance();
            if (rarityBias != null && f.rarity().name().equals(rarityBias)) chance *= 5.0;
            count += chance;
            if (r <= count) return f;
        }
        return available.get(0);
    }

    public FishData getFishById(String id) { return fishList.stream().filter(f -> f.id().equals(id)).findFirst().orElse(null); }
    public List<FishData> getAllFish() { return new ArrayList<>(fishList); }
}