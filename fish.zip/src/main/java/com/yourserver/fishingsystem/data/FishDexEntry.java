package com.yourserver.fishingsystem.data;

/**
 * 魚図鑑の1エントリを表すデータクラス
 */
public record FishDexEntry(
        String fishId,
        int count,
        double maxSize,
        double maxWeight,
        String caughtRanks // カンマ区切りのランク文字列 (例: "D,C,A")
) {}