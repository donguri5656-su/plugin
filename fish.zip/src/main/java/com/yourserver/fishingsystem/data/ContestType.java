package com.yourserver.fishingsystem.data;

public enum ContestType {
    BIGGEST_WEIGHT("最大重量対決", "kg"),
    SMALLEST_WEIGHT("最小重量対決", "kg"),
    LONGEST_SIZE("長さ対決", "cm"),
    SHORTEST_SIZE("最小サイズ対決", "cm"),
    MOST_CATCHES("大量捕獲対決", "匹"),
    TOTAL_WEIGHT("総重量対決", "kg"),
    TOTAL_PRICE("総売上対決", "円"),
    TREASURE_HUNT("宝箱ハンター対決", "個");

    private final String description;
    private final String unit;

    ContestType(String description, String unit) {
        this.description = description;
        this.unit = unit;
    }

    public String getDescription() { return description; }
    public String getUnit() { return unit; }
}