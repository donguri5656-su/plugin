package com.yourserver.fishingsystem.data;

import com.yourserver.fishingsystem.FishingSystem;
import org.bukkit.Bukkit;
import java.io.File;
import java.sql.*;
import java.util.*;

public class DataManager {
    private Connection connection;

    public void setupDatabase() {
        try {
            File dataFolder = FishingSystem.getPlugin().getDataFolder();
            if (!dataFolder.exists()) dataFolder.mkdirs();

            connection = DriverManager.getConnection("jdbc:sqlite:" + new File(dataFolder, "database.db"));
            try (Statement statement = connection.createStatement()) {
                // ※ player_fish_dataテーブルはEconomyCoreによるMySQLへの一元保存へ移行したため、作成・管理ロジックを完全廃止
                statement.execute("CREATE TABLE IF NOT EXISTS player_fish_dex (uuid TEXT, fish_id TEXT, count INTEGER, max_size REAL, max_weight REAL, caught_ranks TEXT, PRIMARY KEY(uuid, fish_id))");

                // 既存DBへのカラム追加
                try {
                    statement.execute("ALTER TABLE player_fish_dex ADD COLUMN caught_ranks TEXT DEFAULT ''");
                } catch (SQLException ignored) {}
            }
        } catch (SQLException e) {
            Bukkit.getLogger().severe("[FishingSystem] データベース接続エラー: " + e.getMessage());
        }
    }

    public void updateDex(UUID uuid, String fishId, double size, double weight, String rankId) {
        if (connection == null) return;

        String currentRanks = "";
        // 1. 現在のランク履歴を取得
        try (PreparedStatement ps = connection.prepareStatement("SELECT caught_ranks FROM player_fish_dex WHERE uuid = ? AND fish_id = ?")) {
            ps.setString(1, uuid.toString());
            ps.setString(2, fishId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                currentRanks = rs.getString("caught_ranks");
            }
        } catch (SQLException e) {
            Bukkit.getLogger().warning("[FishingSystem] ランク取得失敗: " + e.getMessage());
        }

        if (currentRanks == null) currentRanks = "";

        // 2. ランク履歴の更新
        Set<String> rankSet = new HashSet<>();
        if (!currentRanks.isEmpty()) {
            rankSet.addAll(Arrays.asList(currentRanks.split(",")));
        }
        rankSet.add(rankId.toUpperCase());
        String updatedRanks = String.join(",", rankSet);

        // 3. データベースへ保存
        String sql = "INSERT INTO player_fish_dex (uuid, fish_id, count, max_size, max_weight, caught_ranks) VALUES (?, ?, 1, ?, ?, ?) " +
                "ON CONFLICT(uuid, fish_id) DO UPDATE SET count = count + 1, " +
                "max_size = MAX(max_size, EXCLUDED.max_size), " +
                "max_weight = MAX(max_weight, EXCLUDED.max_weight), " +
                "caught_ranks = EXCLUDED.caught_ranks";

        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, uuid.toString());
            ps.setString(2, fishId);
            ps.setDouble(3, size);
            ps.setDouble(4, weight);
            ps.setString(5, updatedRanks);
            ps.executeUpdate();

            Bukkit.getLogger().info("[FishingSystem] " + Bukkit.getOfflinePlayer(uuid).getName() + " の図鑑を更新しました。");
        } catch (SQLException e) {
            Bukkit.getLogger().severe("[FishingSystem] 図鑑保存エラー: " + e.getMessage());
        }
    }

    public PlayerFishData getPlayerData(UUID uuid) {
        // メモリキャッシュ、およびSQLiteへのロード処理を完全廃止
        return new PlayerFishData(uuid);
    }

    public Map<String, FishDexEntry> getPlayerDex(UUID uuid) {
        Map<String, FishDexEntry> dex = new HashMap<>();
        if (connection == null) return dex;
        try (PreparedStatement ps = connection.prepareStatement("SELECT * FROM player_fish_dex WHERE uuid = ?")) {
            ps.setString(1, uuid.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String id = rs.getString("fish_id");
                dex.put(id, new FishDexEntry(id, rs.getInt("count"), rs.getDouble("max_size"), rs.getDouble("max_weight"), rs.getString("caught_ranks")));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return dex;
    }

    public void close() {
        try { if (connection != null) connection.close(); } catch (SQLException e) { e.printStackTrace(); }
    }
}