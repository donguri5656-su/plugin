package com.yourserver.fishingsystem.data;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.util.VaultHook;
import io.papermc.paper.scoreboard.numbers.NumberFormat;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Sound;
import org.bukkit.boss.BarColor;
import org.bukkit.boss.BarStyle;
import org.bukkit.boss.BossBar;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.scoreboard.*;

import java.io.File;
import java.util.*;

public class ContestManager {
    private boolean active = false;
    private boolean feverActive = false;
    private boolean feverRolled = false; // 抽選済みか
    private ContestType currentType = ContestType.BIGGEST_WEIGHT;
    private long endTime = 0;
    private final Map<UUID, Double> scores = new HashMap<>();
    private final Map<UUID, Scoreboard> playerBoards = new HashMap<>();
    private final MiniMessage mm = MiniMessage.miniMessage();
    private BossBar bossBar;
    private BukkitTask updateTask;
    private BukkitTask endTask;
    private final Random random = new Random();

    public void startContest(int minutes, ContestType type) {
        if (active) stopContest();
        this.active = true;
        this.feverActive = false;
        this.feverRolled = false;
        this.currentType = type;
        this.endTime = System.currentTimeMillis() + (minutes * 60L * 1000L);
        this.scores.clear();
        this.playerBoards.clear();

        File file = new File(FishingSystem.getPlugin().getDataFolder(), "contest.yml");
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        Bukkit.broadcast(mm.deserialize(config.getString("messages.start", "<yellow>大会開始！")));

        bossBar = Bukkit.createBossBar("§b§l釣り大会: " + type.getDescription(), BarColor.PINK, BarStyle.SOLID);
        for (Player p : Bukkit.getOnlinePlayers()) {
            bossBar.addPlayer(p);
            p.playSound(p.getLocation(), Sound.EVENT_RAID_HORN, 1.0f, 1.0f);
        }

        updateTask = Bukkit.getScheduler().runTaskTimer(FishingSystem.getPlugin(), () -> {
            long remaining = endTime - System.currentTimeMillis();
            if (remaining <= 0) return;

            // --- フィーバータイムの抽選判定 ---
            int feverLimit = config.getInt("settings.fever-duration-minutes", 3) * 60 * 1000;
            if (!feverRolled && remaining <= feverLimit) {
                feverRolled = true;
                int chance = config.getInt("settings.fever-chance-percent", 20);
                if (random.nextInt(100) < chance) {
                    activateFever(config);
                } else {
                    Bukkit.broadcast(mm.deserialize(config.getString("messages.fever-miss", "")));
                }
            }

            bossBar.setProgress(Math.max(0, (double) remaining / (minutes * 60L * 1000L)));
            String prefix = feverActive ? "§c§l🔥 FEVER 🔥 " : "§b§l釣り大会 §f| ";
            bossBar.setTitle(prefix + "§e残り: " + getTimeLeft());

            for (Player p : Bukkit.getOnlinePlayers()) {
                if (scores.containsKey(p.getUniqueId())) updateIndividualScoreboard(p);
            }
        }, 0L, 20L);

        endTask = Bukkit.getScheduler().runTaskLater(FishingSystem.getPlugin(), this::stopContest, minutes * 60L * 20L);
    }

    private void activateFever(YamlConfiguration config) {
        feverActive = true;
        bossBar.setColor(BarColor.RED);
        Bukkit.broadcast(mm.deserialize(config.getString("messages.fever-start", "<red>FEVER TIME!")));
        for (Player p : Bukkit.getOnlinePlayers()) p.playSound(p.getLocation(), Sound.ENTITY_WITHER_SPAWN, 0.5f, 1.5f);
    }

    public void recordAction(Player player, double value) {
        if (!active) return;
        UUID uuid = player.getUniqueId();
        double topBefore = getTopScore();
        boolean wasFirst = scores.containsKey(uuid) && scores.get(uuid).equals(topBefore) && topBefore != (isSmallWins() ? 999999.0 : 0.0);
        double current = scores.getOrDefault(uuid, isSmallWins() ? 999999.0 : 0.0);
        boolean updated = false;

        if (isSmallWins()) { if (value < current) { scores.put(uuid, value); updated = true; } }
        else {
            if (currentType == ContestType.MOST_CATCHES || currentType == ContestType.TOTAL_WEIGHT || currentType == ContestType.TOTAL_PRICE || currentType == ContestType.TREASURE_HUNT) {
                scores.put(uuid, current + value); updated = true;
            } else if (value > current) {
                scores.put(uuid, value); updated = true;
            }
        }

        if (updated) {
            updateIndividualScoreboard(player);
            double topAfter = getTopScore();
            if ((!isSmallWins() && topAfter > topBefore && scores.get(uuid).equals(topAfter) && !wasFirst) ||
                    (isSmallWins() && topAfter < topBefore && scores.get(uuid).equals(topAfter) && !wasFirst)) {
                broadcastLeaderChange(player, scores.get(uuid));
            }
        }
    }

    private void broadcastLeaderChange(Player player, double score) {
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "contest.yml");
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        String msg = config.getString("messages.new-leader", "").replace("%player%", player.getName()).replace("%score%", String.format("%.1f", score)).replace("%unit%", currentType.getUnit());
        Bukkit.broadcast(mm.deserialize(msg));
        for (Player p : Bukkit.getOnlinePlayers()) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_CHIME, 1.0f, 1.2f);
    }

    private double getTopScore() {
        if (scores.isEmpty()) return isSmallWins() ? 999999.0 : 0.0;
        return isSmallWins() ? Collections.min(scores.values()) : Collections.max(scores.values());
    }

    private boolean isSmallWins() { return currentType == ContestType.SMALLEST_WEIGHT || currentType == ContestType.SHORTEST_SIZE; }

    private void updateIndividualScoreboard(Player player) {
        Scoreboard board = playerBoards.computeIfAbsent(player.getUniqueId(), k -> Bukkit.getScoreboardManager().getNewScoreboard());
        Objective obj = board.getObjective("contest_side");
        if (obj == null) {
            obj = board.registerNewObjective("contest_side", Criteria.DUMMY, mm.deserialize("<gold>🏆 釣り大会"));
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            obj.numberFormat(NumberFormat.blank());
        }
        for (String entry : board.getEntries()) board.resetScores(entry);

        List<Map.Entry<UUID, Double>> sorted = scores.entrySet().stream()
                .sorted((e1, e2) -> isSmallWins() ? e1.getValue().compareTo(e2.getValue()) : e2.getValue().compareTo(e1.getValue())).toList();

        for (int i = 0; i < Math.min(3, sorted.size()); i++) {
            Map.Entry<UUID, Double> e = sorted.get(i);
            String line = "§e" + (i + 1) + ". §f" + Bukkit.getOfflinePlayer(e.getKey()).getName() + " §7(" + String.format("%.1f", e.getValue()) + ")";
            obj.getScore(line).setScore(20 - i);
        }

        int myRank = 0;
        for (int i = 0; i < sorted.size(); i++) { if (sorted.get(i).getKey().equals(player.getUniqueId())) { myRank = i + 1; break; } }
        obj.getScore("§8----------------").setScore(10);
        if (myRank > 3) obj.getScore("§b" + myRank + ". §aYOU §7(" + String.format("%.1f", scores.get(player.getUniqueId())) + ")").setScore(9);
        else if (myRank > 0) obj.getScore("§6§l⭐ 現在入賞中！").setScore(9);
        player.setScoreboard(board);
    }

    public List<String> getLeaderboard() {
        if (scores.isEmpty()) return List.of("<gray>まだ記録はありません。");
        List<Map.Entry<UUID, Double>> sorted = scores.entrySet().stream().sorted((e1, e2) -> isSmallWins() ? e1.getValue().compareTo(e2.getValue()) : e2.getValue().compareTo(e1.getValue())).limit(5).toList();
        return sorted.stream().map(e -> "<gray>" + Bukkit.getOfflinePlayer(e.getKey()).getName() + ": <white>" + String.format("%.1f", e.getValue()) + currentType.getUnit()).toList();
    }

    public void stopContest() {
        if (!active) return;
        this.active = false;
        if (updateTask != null) updateTask.cancel();
        if (endTask != null) endTask.cancel();
        if (bossBar != null) bossBar.removeAll();
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "contest.yml");
        finalizeResults(YamlConfiguration.loadConfiguration(file));
        for (Player p : Bukkit.getOnlinePlayers()) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
        playerBoards.clear();
    }

    private void finalizeResults(YamlConfiguration config) {
        List<Map.Entry<UUID, Double>> sorted = scores.entrySet().stream().sorted((e1, e2) -> isSmallWins() ? e1.getValue().compareTo(e2.getValue()) : e2.getValue().compareTo(e1.getValue())).toList();
        Bukkit.broadcast(mm.deserialize("<#4FC3F7>========= 大会結果発表 [" + currentType.getDescription() + "] ========="));
        if (sorted.isEmpty()) Bukkit.broadcast(mm.deserialize("<gray>参加者なし"));
        else {
            for (int i = 0; i < sorted.size(); i++) {
                UUID uuid = sorted.get(i).getKey();
                int rank = i + 1;
                if (rank <= 3) {
                    Bukkit.broadcast(mm.deserialize("<yellow>" + rank + "位: <white>" + Bukkit.getOfflinePlayer(uuid).getName() + " <gray>(" + String.format("%.1f", sorted.get(i).getValue()) + currentType.getUnit() + ")"));
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null) giveReward(p, rank, config, false);
                } else {
                    Player p = Bukkit.getPlayer(uuid);
                    if (p != null) giveReward(p, rank, config, true);
                }
            }
        }
    }

    private void giveReward(Player player, int rank, YamlConfiguration config, boolean isParticipation) {
        ConfigurationSection section = isParticipation ? config.getConfigurationSection("participation-reward") : config.getConfigurationSection("rewards." + rank);
        if (section == null) return;
        double money = section.getDouble("money", 0);
        if (money > 0 && VaultHook.getEconomy() != null) VaultHook.getEconomy().depositPlayer(player, money);
        for (String cmd : section.getStringList("commands")) Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd.replace("%player%", player.getName()));
        player.sendMessage(mm.deserialize(section.getString("message", "")));
    }

    public boolean isActive() { return active; }
    public boolean isFever() { return active && feverActive; }
    public ContestType getCurrentType() { return currentType; }
    public String getTimeLeft() {
        long left = (endTime - System.currentTimeMillis()) / 1000;
        return left < 0 ? "0:00" : String.format("%d:%02d", left / 60, left % 60);
    }
}