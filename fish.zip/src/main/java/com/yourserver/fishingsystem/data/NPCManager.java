package com.yourserver.fishingsystem.data;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.util.PDCKeys;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Villager;
import org.bukkit.persistence.PersistentDataType;

public class NPCManager {

    /**
     * 売却用NPCを召喚
     */
    public void spawnSellNPC(Location loc) {
        spawnVillager(loc, "<#FFB74D><bold>魚の買取業者", "SELL");
    }

    /**
     * メダル交換用NPCを召喚
     */
    public void spawnMedalNPC(Location loc) {
        spawnVillager(loc, "<#FFD700><bold>メダル交換員", "MEDAL");
    }

    private void spawnVillager(Location loc, String name, String type) {
        var mm = MiniMessage.miniMessage();
        Villager villager = (Villager) loc.getWorld().spawnEntity(loc, EntityType.VILLAGER);
        villager.setCustomNameVisible(true);
        villager.customName(mm.deserialize(name));
        villager.setProfession(Villager.Profession.FISHERMAN);
        villager.setVillagerType(Villager.Type.PLAINS);
        villager.setAI(false);
        villager.setInvulnerable(true);
        villager.setSilent(true);
        villager.setRemoveWhenFarAway(false);

        // PDCに「釣りNPCであること」と「その種類」を保存
        villager.getPersistentDataContainer().set(PDCKeys.IS_NPC, PersistentDataType.BYTE, (byte) 1);
        villager.getPersistentDataContainer().set(PDCKeys.NPC_TYPE, PersistentDataType.STRING, type);
    }

    public boolean removeNearbyNPC(Location loc) {
        return loc.getWorld().getNearbyEntities(loc, 2, 2, 2).stream()
                .filter(e -> e.getPersistentDataContainer().has(PDCKeys.IS_NPC, PersistentDataType.BYTE))
                .peek(org.bukkit.entity.Entity::remove)
                .count() > 0;
    }
}