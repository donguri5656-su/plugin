package com.yourserver.fishingsystem.data;

import com.yourserver.fishingsystem.FishingSystem;
import java.util.UUID;

public class PlayerFishData {
    private final UUID uuid;

    public PlayerFishData(UUID uuid, int level, double exp) {
        this.uuid = uuid;
        setLevel(level);
        setExp(exp);
    }

    public PlayerFishData(UUID uuid) {
        this.uuid = uuid;
    }

    public UUID getUuid() { return uuid; }

    public int getLevel() {
        var api = com.example.economycore.EconomyCore.getInstance().getApi();
        int val = api.get(uuid, "fishing_level");
        return val > 0 ? val : 1; // 初期値 1
    }

    public double getExp() {
        var api = com.example.economycore.EconomyCore.getInstance().getApi();
        int val = api.get(uuid, "fishing_exp");
        return val / 100.0; // 整数型から実数型(double)へ変換して復元
    }

    public void setLevel(int level) {
        var api = com.example.economycore.EconomyCore.getInstance().getApi();
        api.set(uuid, "fishing_level", level);
    }

    public void setExp(double exp) {
        var api = com.example.economycore.EconomyCore.getInstance().getApi();
        api.set(uuid, "fishing_exp", (int) Math.round(exp * 100.0)); // 100倍にして整数として設定
    }

    /**
     * 経験値を加算し、レベルアップしたかどうかを返します
     */
    public boolean addExp(double amount, int nextLevelExp) {
        var api = com.example.economycore.EconomyCore.getInstance().getApi();
        double currentExp = getExp() + amount;
        int currentLevel = getLevel();
        boolean leveledUp = false;

        // 必要に応じて複数の一括レベルアップに対応できるようループ処理で判定
        while (currentExp >= nextLevelExp) {
            currentLevel++;
            currentExp -= nextLevelExp;
            leveledUp = true;
            nextLevelExp = FishingSystem.getPlugin().getLevelManager().getRequiredExp(currentLevel);
        }

        api.set(uuid, "fishing_level", currentLevel);
        api.set(uuid, "fishing_exp", (int) Math.round(currentExp * 100.0));
        return leveledUp;
    }
}