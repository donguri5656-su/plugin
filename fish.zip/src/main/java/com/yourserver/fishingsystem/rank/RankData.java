package com.yourserver.fishingsystem.rank;

import org.bukkit.Sound;

/**
 * ランクのデータを保持するレコードです。
 */
public record RankData(
        String id,
        double chance,
        double multiplier,
        double expMultiplier,
        double minPercent,
        double maxPercent,
        Sound sound
) {}