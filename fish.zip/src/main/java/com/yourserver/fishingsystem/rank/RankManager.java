package com.yourserver.fishingsystem.rank;

import com.yourserver.fishingsystem.FishingSystem;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class RankManager {
    private final List<RankData> rankList = new ArrayList<>();
    private final Random random = new Random();

    public void loadRanks() {
        rankList.clear();
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "ranks.yml");
        if (!file.exists()) {
            FishingSystem.getPlugin().saveResource("ranks.yml", false);
        }
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("ranks");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            Sound sound;
            try { sound = Sound.valueOf(section.getString(id + ".sound", "ENTITY_EXPERIENCE_ORB_PICKUP")); }
            catch (Exception e) { sound = Sound.ENTITY_EXPERIENCE_ORB_PICKUP; }

            rankList.add(new RankData(
                    id,
                    section.getDouble(id + ".chance"),
                    section.getDouble(id + ".multiplier"),
                    section.getDouble(id + ".exp-multiplier"),
                    section.getDouble(id + ".size-percent.min"),
                    section.getDouble(id + ".size-percent.max"),
                    sound
            ));
        }
    }

    public RankData getRankById(String id) {
        return rankList.stream().filter(r -> r.id().equals(id)).findFirst().orElse(null);
    }

    public RankData chooseRandomRank() {
        if (rankList.isEmpty()) return null;
        double totalChance = rankList.stream().mapToDouble(RankData::chance).sum();
        double r = random.nextDouble() * totalChance;
        double countChance = 0.0;
        for (RankData rank : rankList) {
            countChance += rank.chance();
            if (r <= countChance) return rank;
        }
        return rankList.get(0);
    }
}