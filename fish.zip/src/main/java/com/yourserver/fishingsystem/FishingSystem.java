package com.yourserver.fishingsystem;

import com.yourserver.fishingsystem.command.*;
import com.yourserver.fishingsystem.data.*;
import com.yourserver.fishingsystem.fish.FishManager;
import com.yourserver.fishingsystem.level.LevelManager;
import com.yourserver.fishingsystem.rank.RankManager;
import com.yourserver.fishingsystem.item.*;
import com.yourserver.fishingsystem.treasure.TreasureManager;
import com.yourserver.fishingsystem.listener.*;
import com.yourserver.fishingsystem.util.VaultHook;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

public class FishingSystem extends JavaPlugin {
    private static FishingSystem plugin;
    private FishManager fishManager;
    private RankManager rankManager;
    private DataManager dataManager;
    private LevelManager levelManager;
    private NPCManager npcManager;
    private TreasureManager treasureManager;
    private RodManager rodManager;
    private BaitManager baitManager;
    private ContestManager contestManager;

    @Override
    public void onEnable() {
        plugin = this;
        saveDefaultConfig();
        VaultHook.setupEconomy();

        // 初期化
        this.dataManager = new DataManager();
        this.dataManager.setupDatabase();
        this.levelManager = new LevelManager();
        this.fishManager = new FishManager();
        this.fishManager.loadFish();
        this.rankManager = new RankManager();
        this.rankManager.loadRanks();
        this.npcManager = new NPCManager();
        this.treasureManager = new TreasureManager();
        this.treasureManager.loadTreasures();
        this.rodManager = new RodManager();
        this.rodManager.loadRods();
        this.baitManager = new BaitManager();
        this.baitManager.loadBaits();
        this.contestManager = new ContestManager();

        // ※ PAPIプレースホルダーはEconomyCoreが直接自動登録して配布するため、釣りプラグイン側での拡張登録は廃止されました

        getCommand("fish").setExecutor(new FishCommand());
        getCommand("fish").setTabCompleter(new FishTabCompleter());

        getServer().getPluginManager().registerEvents(new FishingListener(), this);
        getServer().getPluginManager().registerEvents(new GUIListener(), this);
        getServer().getPluginManager().registerEvents(new NPCListener(), this);
        getServer().getPluginManager().registerEvents(new TreasureListener(), this);
        getServer().getPluginManager().registerEvents(new BaitBagListener(), this);
        getServer().getPluginManager().registerEvents(new DexItemListener(), this);

        getLogger().info("FishingSystem Version 1.0 Fully Loaded!");
    }

    @Override
    public void onDisable() { if (dataManager != null) dataManager.close(); }

    public static FishingSystem getPlugin() { return plugin; }
    public FishManager getFishManager() { return fishManager; }
    public RankManager getRankManager() { return rankManager; }
    public DataManager getDataManager() { return dataManager; }
    public LevelManager getLevelManager() { return levelManager; }
    public NPCManager getNpcManager() { return npcManager; }
    public TreasureManager getTreasureManager() { return treasureManager; }
    public RodManager getRodManager() { return rodManager; }
    public BaitManager getBaitManager() { return baitManager; }
    public ContestManager getContestManager() { return contestManager; }
}