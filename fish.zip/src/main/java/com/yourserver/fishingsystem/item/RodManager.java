package com.yourserver.fishingsystem.item;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.util.PDCKeys;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.io.File;
import java.util.*;

public class RodManager {
    private final Map<String, RodData> rodMap = new HashMap<>();

    public void loadRods() {
        rodMap.clear();
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "rods.yml");
        if (!file.exists()) FishingSystem.getPlugin().saveResource("rods.yml", false);
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("rods");
        if (section == null) return;

        for (String id : section.getKeys(false)) {
            rodMap.put(id, new RodData(
                    id, section.getString(id + ".display-name"), section.getInt(id + ".custom-model-data"),
                    section.getStringList(id + ".lore"), section.getDouble(id + ".abilities.exp-multiplier", 1.0),
                    section.getDouble(id + ".abilities.treasure-add-chance", 0.0), section.getDouble(id + ".abilities.rank-bonus", 0.0),
                    section.getDouble(id + ".abilities.medal-chance", 0.0), section.getString(id + ".abilities.medal-amount", "1-1")
            ));
        }
        Bukkit.getLogger().info("[FishingSystem] " + rodMap.size() + " 種類の竿を読み込みました。");
    }

    public Set<String> getAllRodIds() { return rodMap.keySet(); }

    public ItemStack createRod(String id) {
        RodData data = rodMap.get(id);
        if (data == null) return null;
        ItemStack rod = new ItemStack(Material.FISHING_ROD);
        rod.editMeta(meta -> {
            meta.displayName(ItemManager.parseColor(data.displayName()));
            List<Component> lore = new ArrayList<>();
            for (String line : data.lore()) lore.add(ItemManager.parseColor(line));
            meta.lore(lore);
            meta.setCustomModelData(data.customModelData());
            var pdc = meta.getPersistentDataContainer();
            pdc.set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "custom_rod");
            pdc.set(PDCKeys.ROD_ID, PersistentDataType.STRING, id);
            pdc.set(PDCKeys.ROD_EXP_BONUS, PersistentDataType.DOUBLE, data.expMult());
            pdc.set(PDCKeys.ROD_TREASURE_BONUS, PersistentDataType.DOUBLE, data.treasurePlus());
            pdc.set(PDCKeys.ROD_RANK_BONUS, PersistentDataType.DOUBLE, data.rankBonus());
            pdc.set(PDCKeys.ROD_MEDAL_CHANCE, PersistentDataType.DOUBLE, data.medalChance());
            pdc.set(PDCKeys.ROD_MEDAL_AMOUNT, PersistentDataType.STRING, data.medalAmount());
        });
        return rod;
    }

    public record RodData(String id, String displayName, int customModelData, List<String> lore, double expMult, double treasurePlus, double rankBonus, double medalChance, String medalAmount) {}
}