package com.yourserver.fishingsystem.item;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.fish.FishRarity;
import com.yourserver.fishingsystem.util.PDCKeys;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;
import org.yaml.snakeyaml.external.biz.base64Coder.Base64Coder;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.*;

public class BaitManager {
    private final Map<String, BaitData> baitMap = new HashMap<>();

    public void loadBaits() {
        baitMap.clear();
        File file = new File(FishingSystem.getPlugin().getDataFolder(), "baits.yml");
        if (!file.exists()) FishingSystem.getPlugin().saveResource("baits.yml", false);
        YamlConfiguration config = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection section = config.getConfigurationSection("baits");
        if (section == null) return;
        for (String id : section.getKeys(false)) {
            FishRarity rarity;
            try { rarity = FishRarity.valueOf(section.getString(id + ".rarity", "COMMON").toUpperCase()); }
            catch (Exception e) { rarity = FishRarity.COMMON; }

            baitMap.put(id, new BaitData(
                    id, section.getString(id + ".display-name"), rarity,
                    section.getInt(id + ".custom-model-data"), section.getStringList(id + ".lore"),
                    section.getDouble(id + ".boosts.exp-multiplier", 1.0),
                    section.getDouble(id + ".boosts.size-multiplier", 1.0),
                    section.getDouble(id + ".boosts.weight-multiplier", 1.0),
                    section.getDouble(id + ".boosts.price-multiplier", 1.0),
                    section.getDouble(id + ".boosts.treasure-boost", 0.0),
                    section.getDouble(id + ".boosts.time-multiplier", 1.0),
                    section.getString(id + ".boosts.rarity-bias", "NONE")
            ));
        }
    }

    public BaitData getBaitData(String id) { return baitMap.get(id); }
    public Set<String> getAllBaitIds() { return baitMap.keySet(); }

    public ItemStack createBaitBag() {
        ItemStack bag = new ItemStack(Material.CHEST_MINECART);
        bag.editMeta(meta -> {
            meta.displayName(ItemManager.parseColor("<#FFB74D><bold>餌バッグ"));
            meta.lore(List.of(ItemManager.parseColor("<gray>右クリックで餌を収納"), ItemManager.parseColor("<gray>釣り中に自動消費してボーナス！")));
            meta.setCustomModelData(6001);
            meta.getPersistentDataContainer().set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "bait_bag");
        });
        return bag;
    }

    public ItemStack createBait(String id) {
        BaitData data = baitMap.get(id);
        if (data == null) return null;
        return ItemManager.createBaitItem(data.id(), data.displayName(), data.rarity(), data.lore(), data.customModelData());
    }

    public void openBaitBag(Player player, ItemStack bag) {
        Inventory inv = Bukkit.createInventory(null, 9, MiniMessage.miniMessage().deserialize("餌バッグの中身"));
        String encoded = bag.getItemMeta().getPersistentDataContainer().get(PDCKeys.BAIT_BAG_DATA, PersistentDataType.STRING);
        if (encoded != null && !encoded.isEmpty()) inv.setContents(deserializeItems(encoded));
        player.openInventory(inv);
    }

    public String serializeItems(ItemStack[] items) {
        try (ByteArrayOutputStream o = new ByteArrayOutputStream(); BukkitObjectOutputStream d = new BukkitObjectOutputStream(o)) {
            d.writeInt(items.length);
            for (ItemStack i : items) d.writeObject(i);
            return Base64Coder.encodeLines(o.toByteArray());
        } catch (Exception e) { return ""; }
    }

    public ItemStack[] deserializeItems(String data) {
        try (ByteArrayInputStream i = new ByteArrayInputStream(Base64Coder.decodeLines(data)); BukkitObjectInputStream d = new BukkitObjectInputStream(i)) {
            ItemStack[] items = new ItemStack[d.readInt()];
            for (int n = 0; n < items.length; n++) items[n] = (ItemStack) d.readObject();
            return items;
        } catch (Exception e) { return new ItemStack[9]; }
    }

    public record BaitData(String id, String displayName, FishRarity rarity, int customModelData, List<String> lore,
                           double expMult, double sizeMult, double weightMult, double priceMult,
                           double treasureBoost, double timeMult, String rarityBias) {}
}