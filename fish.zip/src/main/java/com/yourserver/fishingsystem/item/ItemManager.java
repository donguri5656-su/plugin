package com.yourserver.fishingsystem.item;

import com.yourserver.fishingsystem.fish.FishRarity;
import com.yourserver.fishingsystem.util.PDCKeys;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Material;
import org.bukkit.inventory.ItemStack;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.List;

public class ItemManager {

    /**
     * レガシーカラーコードおよびアンパサンド(&)付きのカラーコードを MiniMessage 互換のタグに変換します
     */
    private static String legacyToMiniMessage(String text) {
        if (text == null) return "";
        String result = text.replace("§", "&");
        result = result
                .replace("&0", "<black>")
                .replace("&1", "<dark_blue>")
                .replace("&2", "<dark_green>")
                .replace("&3", "<dark_aqua>")
                .replace("&4", "<dark_red>")
                .replace("&5", "<dark_purple>")
                .replace("&6", "<gold>")
                .replace("&7", "<gray>")
                .replace("&8", "<dark_gray>")
                .replace("&9", "<blue>")
                .replace("&a", "<green>")
                .replace("&b", "<aqua>")
                .replace("&c", "<red>")
                .replace("&d", "<light_purple>")
                .replace("&e", "<yellow>")
                .replace("&f", "<white>")
                .replace("&k", "<obfuscated>")
                .replace("&l", "<bold>")
                .replace("&m", "<strikethrough>")
                .replace("&n", "<underlined>")
                .replace("&o", "<italic>")
                .replace("&r", "<reset>");
        return result;
    }

    public static Component parseColor(String text) {
        if (text == null || text.isEmpty()) return Component.empty();
        // レガシーコードをMiniMessageタグに事前変換することで例外の発生を防止します
        String processed = legacyToMiniMessage(text);
        return MiniMessage.miniMessage().deserialize("<reset><gray>" + processed).decoration(TextDecoration.ITALIC, false);
    }

    private static String getRankColor(String rank) {
        return switch (rank.toUpperCase()) {
            case "D" -> "<gray>";
            case "C" -> "<green>";
            case "B" -> "<aqua>";
            case "A" -> "<yellow>";
            case "S" -> "<gold>";
            case "SS" -> "<light_purple>";
            case "SSS" -> "<red><bold>";
            default -> "<white>";
        };
    }

    public static ItemStack createFishItem(String fishId, String rawName, FishRarity rarity, List<String> lore, int cmd, String rank, double size, double weight, double price) {
        ItemStack item = new ItemStack(Material.COD);
        item.editMeta(meta -> {
            meta.displayName(parseColor(rarity.getColorTag() + rawName));
            String coloredRank = getRankColor(rank) + rank + "<gray>";
            String coloredSize = "<yellow>" + String.format("%.1f", size) + "<gray>";
            String coloredWeight = "<gold>" + String.format("%.1f", weight) + "<gray>";
            String coloredPrice = "<green>" + String.format("%.1f", price) + "<white>円<gray>";

            List<Component> finalLore = new ArrayList<>();
            finalLore.add(parseColor("<gray>レア度: " + rarity.getColorTag() + rarity.getDisplayName()));
            finalLore.add(Component.empty());
            finalLore.add(parseColor("<yellow><bold>【ステータス】"));
            if (lore != null) {
                for (String line : lore) {
                    finalLore.add(parseColor("<white>" + line.replace("%rank%", coloredRank).replace("%size%", coloredSize).replace("%weight%", coloredWeight).replace("%price%", coloredPrice)));
                }
            }
            meta.lore(finalLore);
            meta.setCustomModelData(cmd);
            var pdc = meta.getPersistentDataContainer();
            pdc.set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "fish");
            pdc.set(PDCKeys.FISH_ID, PersistentDataType.STRING, fishId);
            pdc.set(PDCKeys.RANK, PersistentDataType.STRING, rank);
            pdc.set(PDCKeys.SIZE, PersistentDataType.DOUBLE, size);
            pdc.set(PDCKeys.WEIGHT, PersistentDataType.DOUBLE, weight);
        });
        return item;
    }

    public static ItemStack createBaitItem(String baitId, String rawName, FishRarity rarity, List<String> lore, int cmd) {
        ItemStack item = new ItemStack(Material.CLAY_BALL);
        item.editMeta(meta -> {
            meta.displayName(parseColor(rarity.getColorTag() + rawName));
            List<Component> finalLore = new ArrayList<>();
            finalLore.add(parseColor("<gray>レア度: " + rarity.getColorTag() + rarity.getDisplayName()));
            finalLore.add(Component.empty());
            if (lore != null) {
                for (String line : lore) finalLore.add(parseColor(line));
            }
            meta.lore(finalLore);
            meta.setCustomModelData(cmd);
            var pdc = meta.getPersistentDataContainer();
            pdc.set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "bait");
            pdc.set(PDCKeys.BAIT_ID, PersistentDataType.STRING, baitId);
        });
        return item;
    }

    public static ItemStack createMedalItem(int amount) {
        ItemStack medal = new ItemStack(Material.IRON_NUGGET, amount);
        medal.editMeta(meta -> {
            meta.displayName(parseColor("<#FFD700><bold>🎰 ゲーセンメダル"));
            meta.lore(List.of(parseColor("<gray>特別な景品と交換できるメダル。")));
            meta.setCustomModelData(5001);
            meta.getPersistentDataContainer().set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "medal");
        });
        return medal;
    }

    public static ItemStack createFishDexItem() {
        ItemStack item = new ItemStack(Material.BOOK);
        item.editMeta(meta -> {
            meta.displayName(parseColor("<#4FC3F7><bold>魚類百科事典"));
            meta.lore(List.of(parseColor("<gray>これまでに釣った魚の記録。"), parseColor(""), parseColor("<aqua>右クリックで開く")));
            meta.setCustomModelData(7001);
            meta.getPersistentDataContainer().set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "fish_dex_item");
        });
        return item;
    }

    public static ItemStack createBaitDexItem() {
        ItemStack item = new ItemStack(Material.BOOK);
        item.editMeta(meta -> {
            meta.displayName(parseColor("<#A1887F><bold>釣り餌カタログ"));
            meta.lore(List.of(parseColor("<gray>世界中の釣り餌の性能まとめ。"), parseColor(""), parseColor("<aqua>右クリックで開く")));
            meta.setCustomModelData(7002);
            meta.getPersistentDataContainer().set(PDCKeys.ITEM_TYPE, PersistentDataType.STRING, "bait_dex_item");
        });
        return item;
    }

    public static String getFishId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(PDCKeys.FISH_ID, PersistentDataType.STRING);
    }

    public static String getRank(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(PDCKeys.RANK, PersistentDataType.STRING);
    }
}