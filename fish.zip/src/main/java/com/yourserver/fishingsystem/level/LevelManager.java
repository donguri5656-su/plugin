package com.yourserver.fishingsystem.level;

import com.yourserver.fishingsystem.FishingSystem;
import org.bukkit.configuration.file.FileConfiguration;

public class LevelManager {

    // 次のレベルに必要な経験値を計算
    public int getRequiredExp(int currentLevel) {
        FileConfiguration config = FishingSystem.getPlugin().getConfig();
        // コンフィグから設定を読み込む例（デフォルト値あり）
        int startExp = config.getInt("level-settings.start-exp", 100);
        int increase = config.getInt("level-settings.increase", 20);

        return startExp + (currentLevel - 1) * increase;
    }
}