package com.yourserver.fishingsystem.util;

import com.yourserver.fishingsystem.FishingSystem;
import org.bukkit.NamespacedKey;

public class PDCKeys {
    public static final NamespacedKey ITEM_TYPE = new NamespacedKey(FishingSystem.getPlugin(), "item_type");
    public static final NamespacedKey FISH_ID = new NamespacedKey(FishingSystem.getPlugin(), "fish_id");
    public static final NamespacedKey RANK = new NamespacedKey(FishingSystem.getPlugin(), "rank");
    public static final NamespacedKey SIZE = new NamespacedKey(FishingSystem.getPlugin(), "size");
    public static final NamespacedKey WEIGHT = new NamespacedKey(FishingSystem.getPlugin(), "weight");
    public static final NamespacedKey IS_NPC = new NamespacedKey(FishingSystem.getPlugin(), "is_fishing_npc");
    public static final NamespacedKey NPC_TYPE = new NamespacedKey(FishingSystem.getPlugin(), "npc_type");
    public static final NamespacedKey ROD_ID = new NamespacedKey(FishingSystem.getPlugin(), "rod_id");
    public static final NamespacedKey ROD_TREASURE_BONUS = new NamespacedKey(FishingSystem.getPlugin(), "rod_treasure_bonus");
    public static final NamespacedKey ROD_EXP_BONUS = new NamespacedKey(FishingSystem.getPlugin(), "rod_exp_bonus");
    public static final NamespacedKey ROD_RANK_BONUS = new NamespacedKey(FishingSystem.getPlugin(), "rod_rank_bonus");
    public static final NamespacedKey ROD_MEDAL_CHANCE = new NamespacedKey(FishingSystem.getPlugin(), "rod_medal_chance");
    public static final NamespacedKey ROD_MEDAL_AMOUNT = new NamespacedKey(FishingSystem.getPlugin(), "rod_medal_amount");
    public static final NamespacedKey BAIT_ID = new NamespacedKey(FishingSystem.getPlugin(), "bait_id");
    public static final NamespacedKey BAIT_BAG_DATA = new NamespacedKey(FishingSystem.getPlugin(), "bait_bag_data");
    public static final NamespacedKey EXCHANGE_ID = new NamespacedKey(FishingSystem.getPlugin(), "exchange_id");
}