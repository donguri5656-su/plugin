package com.yourserver.fishingsystem.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;

public class ProgressUtil {

    /**
     * 進捗バーの文字列を生成します
     * @param current 現在の経験値
     * @param max 必要経験値
     * @param width バーの長さ（マスの数）
     * @return 色付きの進捗バー
     */
    public static String getProgressBar(double current, double max, int width) {
        double percent = current / max;
        int progressCount = (int) (width * percent);
        int leftCount = width - progressCount;

        StringBuilder bar = new StringBuilder("<aqua>");
        for (int i = 0; i < progressCount; i++) {
            bar.append("■");
        }
        bar.append("<gray>");
        for (int i = 0; i < leftCount; i++) {
            bar.append("■");
        }

        return bar.toString();
    }
}