package com.yourserver.fishingsystem.command;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.data.ContestType;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.util.StringUtil;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FishTabCompleter implements TabCompleter {

    @Override
    public @Nullable List<String> onTabComplete(@NotNull CommandSender sender, @NotNull Command command, @NotNull String alias, @NotNull String[] args) {
        List<String> completions = new ArrayList<>();
        List<String> hints = new ArrayList<>();

        if (args.length == 1) {
            hints.addAll(Arrays.asList("stats", "sell", "dex", "baits", "help", "contest"));
            if (sender.isOp()) hints.addAll(Arrays.asList("reload", "give", "npc"));
        }
        else if (args.length == 2) {
            if (args[0].equalsIgnoreCase("give")) hints.addAll(Arrays.asList("rod", "bag", "bait"));
            if (args[0].equalsIgnoreCase("npc")) hints.addAll(Arrays.asList("spawn", "medal", "remove"));
            if (args[0].equalsIgnoreCase("contest")) {
                hints.add("top");
                if (sender.isOp()) { hints.add("start"); hints.add("stop"); }
            }
        }
        else if (args.length == 3) {
            if (args[0].equalsIgnoreCase("give")) {
                if (args[1].equalsIgnoreCase("rod")) hints.addAll(FishingSystem.getPlugin().getRodManager().getAllRodIds());
                if (args[1].equalsIgnoreCase("bait")) hints.addAll(FishingSystem.getPlugin().getBaitManager().getAllBaitIds());
            }
            if (args[0].equalsIgnoreCase("contest") && args[1].equalsIgnoreCase("start")) hints.add("15");
        }
        else if (args.length == 4) {
            if (args[0].equalsIgnoreCase("contest") && args[1].equalsIgnoreCase("start")) {
                for (ContestType type : ContestType.values()) hints.add(type.name());
            }
        }

        return StringUtil.copyPartialMatches(args[args.length - 1], hints, completions);
    }
}