package com.yourserver.fishingsystem.command;

import com.yourserver.fishingsystem.FishingSystem;
import com.yourserver.fishingsystem.data.PlayerFishData;
import com.yourserver.fishingsystem.data.ContestType;
import com.yourserver.fishingsystem.gui.DexGUI;
import com.yourserver.fishingsystem.gui.SellGUI;
import com.yourserver.fishingsystem.gui.BaitDexGUI;
import com.yourserver.fishingsystem.item.ItemManager;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.jetbrains.annotations.NotNull;

public class FishCommand implements CommandExecutor {

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command, @NotNull String label, @NotNull String[] args) {
        var mm = MiniMessage.miniMessage();

        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            sender.sendMessage(mm.deserialize("<#4FC3F7>==== FishingSystem HELP ===="));
            sender.sendMessage(mm.deserialize("<white>/fish stats <gray>- レベル確認"));
            sender.sendMessage(mm.deserialize("<white>/fish dex <gray>- 魚図鑑"));
            sender.sendMessage(mm.deserialize("<white>/fish baits <gray>- 餌図鑑"));
            sender.sendMessage(mm.deserialize("<white>/fish sell <gray>- 売却GUI"));
            sender.sendMessage(mm.deserialize("<white>/fish contest top <gray>- 大会順位"));
            if (sender.isOp()) {
                sender.sendMessage(mm.deserialize("<red>--- 管理者用 ---"));
                sender.sendMessage(mm.deserialize("<red>/fish reload <gray>- 全リロード"));
                sender.sendMessage(mm.deserialize("<red>/fish give [rod/bag/bait/fishdex/baitdex] <ID>"));
                sender.sendMessage(mm.deserialize("<red>/fish contest [start/stop]"));
                sender.sendMessage(mm.deserialize("<red>/fish npc [spawn/medal/remove]"));
            }
            return true;
        }

        String sub = args[0].toLowerCase();

        if (sub.equals("reload") && sender.isOp()) {
            FishingSystem.getPlugin().getFishManager().loadFish();
            FishingSystem.getPlugin().getRankManager().loadRanks();
            FishingSystem.getPlugin().getTreasureManager().loadTreasures();
            FishingSystem.getPlugin().getRodManager().loadRods();
            FishingSystem.getPlugin().getBaitManager().loadBaits();
            sender.sendMessage(mm.deserialize("<green>全データのリロードが完了しました！"));
            return true;
        }

        if (sub.equals("contest")) {
            if (args.length > 1) {
                String action = args[1].toLowerCase();
                if (action.equals("start") && args.length >= 4 && sender.isOp()) {
                    try {
                        int mins = Integer.parseInt(args[2]);
                        ContestType type = ContestType.valueOf(args[3].toUpperCase());
                        FishingSystem.getPlugin().getContestManager().startContest(mins, type);
                    } catch (Exception e) { sender.sendMessage(mm.deserialize("<red>引数が無効です。")); }
                    return true;
                }
                if (action.equals("stop") && sender.isOp()) {
                    FishingSystem.getPlugin().getContestManager().stopContest();
                    sender.sendMessage(mm.deserialize("<yellow>大会を終了しました。"));
                    return true;
                }
                if (action.equals("top")) {
                    if (!FishingSystem.getPlugin().getContestManager().isActive()) {
                        sender.sendMessage(mm.deserialize("<red>現在、大会は開催されていません。"));
                        return true;
                    }
                    sender.sendMessage(mm.deserialize("<#4FC3F7>==== 大会順位 (残り: " + FishingSystem.getPlugin().getContestManager().getTimeLeft() + ") ===="));
                    FishingSystem.getPlugin().getContestManager().getLeaderboard().forEach(line -> sender.sendMessage(mm.deserialize(line)));
                    return true;
                }
            }
        }

        if (sub.equals("give") && sender.isOp() && sender instanceof Player player) {
            if (args.length >= 2) {
                String type = args[1].toLowerCase();
                switch (type) {
                    case "rod" -> {
                        if (args.length >= 3) {
                            ItemStack rod = FishingSystem.getPlugin().getRodManager().createRod(args[2]);
                            if (rod != null) player.getInventory().addItem(rod);
                        }
                    }
                    case "bag" -> player.getInventory().addItem(FishingSystem.getPlugin().getBaitManager().createBaitBag());
                    case "bait" -> {
                        if (args.length >= 3) {
                            ItemStack bait = FishingSystem.getPlugin().getBaitManager().createBait(args[2]);
                            if (bait != null) player.getInventory().addItem(bait);
                        }
                    }
                    case "fishdex" -> player.getInventory().addItem(ItemManager.createFishDexItem());
                    case "baitdex" -> player.getInventory().addItem(ItemManager.createBaitDexItem());
                }
                return true;
            }
        }

        if (sender instanceof Player player) {
            switch (sub) {
                case "stats" -> {
                    PlayerFishData d = FishingSystem.getPlugin().getDataManager().getPlayerData(player.getUniqueId());
                    player.sendMessage(mm.deserialize("<#4FC3F7>釣りレベル: <aqua>Lv." + d.getLevel()));
                }
                case "dex" -> DexGUI.openDex(player);
                case "baits" -> BaitDexGUI.openBaitDex(player);
                case "sell" -> SellGUI.openSellGUI(player);
                case "npc" -> {
                    if (player.isOp() && args.length >= 2) {
                        String npcAction = args[1].toLowerCase();
                        if (npcAction.equals("spawn")) FishingSystem.getPlugin().getNpcManager().spawnSellNPC(player.getLocation());
                        else if (npcAction.equals("medal")) FishingSystem.getPlugin().getNpcManager().spawnMedalNPC(player.getLocation());
                        else if (npcAction.equals("remove")) FishingSystem.getPlugin().getNpcManager().removeNearbyNPC(player.getLocation());
                    }
                }
            }
        }
        return true;
    }
}